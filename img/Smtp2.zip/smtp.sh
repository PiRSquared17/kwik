#!/bin/sh

################################################################################
# Shell script SMTP server.
#
# Intended to run under inetd.
#
# The received mail can be sent to
# another mailbox in another server
# or be saved in a file.
# Can be easily customized. Can save you typing.
#
################################################################################

################################################################################
# Functions definition
################################################################################

#
# Function to read the commands:
# separates the command from the parameter
#
read_commands () {
  read -t 20 input

  #first of all we test timeouts to stop the daemon
  if [ $? -ne 0 ]; then exit

	#we have to filter the deadly CR char
	#Internet communications mandate the use of CR+LF
	#but our shell routines doesn't expect any CR
	#we can see that by filtering $input to | cat -v
	input=`echo $input | tr -d '\r'`

	#in most used commands, and those implemented here
  #we expect a double colon as a divider in the form command:parameter
  #with a exception, HELO and its argument aren't divided by a :
  divider=':'
  if [ "`echo $input | grep :`" = '' ]; then #in bash: "${command:0:4}"
    divider=' '
  fi

  #change the command to uppercase
  command=`echo ${input%$divider*} | tr '[a-z]' '[A-Z]'`


  #remove padding characters from the parameter
  parameter=`echo ${input#*$divider} | sed 's/[ <>]//g'`

}

#
# Function to process the commands and offer a RFC821 response:
# not a strict implementation, only most used commands
#
process_commands() {
  case $command in
    'QUIT')
      echo '221 Bye'
      exit
    ;;

    'HELO')
      echo "250 $parameter"
      return
    ;;

    'MAIL FROM')
      if [ "$parameter" = '' ]; then
        echo '501 Bad syntax'
        return
      fi
      status=1
      sender=$parameter
      echo '250 Ok'
      return
    ;;

    'RCPT TO')
      if [ "$status" != 1 ]; then
        echo '503 Error: need MAIL command'
        return
      fi
      if [ "$parameter" = '' ]; then
        echo '501 Bad syntax'
        return
      fi
      if [ "$parameter" != 'guru@olas.ath.cx' ]; then
        echo '554 User unknown'
        return
      fi
      status=2
      echo '250 Ok'
      return
    ;;

    'DATA')
      if [ "$status" != 2 ]; then
        echo '503 Error: need RCPT command'
        return
      fi
      status=3
      echo '354 Please enter the message. End with CRLF.CRLF'
      return
    ;;

    *)
      #no match? command unknown
      echo '502 Error: command not implemented'
    ;;

  esac
}

#
# Function to read the DATA of the message:
# just reads, because no parsing is necessary
#
read_data () {
  read input

  #first of all we test timeouts to stop the daemon
  if [ $? -ne 0 ]; then exit

	#we filter the deadly CR char
	input=`echo $input | tr -d '\r'`
}

#
# Function to process the DATA of the message and redirect it somewhere: a file, a server...
#
process_data() {
  data="$data\n$input"
  if [ "$input" = '.' ]; then
    status=0
    echo '250 Queued'
#    echo -e $sender'\n'$data >> sms
    echo -e $sender'\n'$data | mini_sendmail -f$parameter -salt1.gmail-smtp-in.l.google.com -v daniel.cr.ht@gmail.com
    data=''
  fi
  
}


################################################################################
# Main program
################################################################################

status=0
#0 initial, 1 mail, 2 rcpt, 3 data
#a smpt daemon passes thru different stages
#every state expects certain commands
#and treats the input accordingly

#welcome message
echo '220 SMTP'

#loop eternally
while :
do

  #first 3 states accepts commands
  #the last only reads the email data
  if [ "$status" -lt 3 ]; then
    read_commands
    process_commands
  else
    read_data
    process_data
  fi


done

# regex that can filter a mail address
# \b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b

#  if [ `expr "$input" : '\(....\)'` = 'HELO' ]; then #in bash: "${command:0:4}"
