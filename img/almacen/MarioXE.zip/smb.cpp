//20-Dic-2000
#define WIN32_LEAN_AND_MEAN

// ENCABEZAMIENTOS /////////////////////////////////////////////////////////
#include "windows.h"
#include "ddraw.h"

// DEFINICIONES //////////////////////////////////////////////////////////
#define MODO_X 320
#define MODO_Y 200
#define MODO_BPP 16
#define NUM_SPR 8
#define BOWSER 6
#define TROOPA 2
#define PARATROOPA 7
#define GOOMBA 4
#define BOMBOMB 5

// PROTOTIPOS ///////////////////////////////////////////////////////
LRESULT CALLBACK WndFunc(HWND hwnd, UINT mensaje, WPARAM wParam, LPARAM lParam);
void Salta();
BOOL IniciaVentana(HINSTANCE hInst, int nCmdMuestra );
BOOL IniciaDirDraw();
void DimensionaSprites();
void Anda();
void CargaMapa();
BOOL Solap(int sx,int sy,char sp);
void Destruye();
void Redibuja();
void LeeTeclado();
void Comprueba();
IDirectDrawSurface* CreaSuperficieBitmap(IDirectDraw* directdraw, LPCTSTR file, int dw, int dh);

// GLOBALES //////////////////////////////////////////////////////////
HWND hwnd;
RECT rcfondo;
RECT rcsprites[NUM_SPR];
LPDIRECTDRAW ddraw;
LPDIRECTDRAWSURFACE pag_visibl;
LPDIRECTDRAWSURFACE pag_dibujo;
LPDIRECTDRAWSURFACE fondo;
LPDIRECTDRAWSURFACE sprites;
long dimrcancho[NUM_SPR], dimrcalto[NUM_SPR];

int x=26, xh, y=177;
int a=120, b=30, c=90, d=50;
float e=60;
int x1, x2, y2, ys;
char bros=0;
char jc, jt, f[4];
DWORD wd[NUM_SPR], jd;
char map[888];

// WINMAIN //////////////////////////////////////////////////////////
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpszCmdParam, int nCmdMuestra)
{
	MSG msg;
    lpszCmdParam = lpszCmdParam;
    hPrevInst = hPrevInst;

   	DimensionaSprites();
	CargaMapa();

	if(!IniciaVentana(hInst, nCmdMuestra)) return FALSE;
	if(!IniciaDirDraw()) return FALSE;

	fondo = CreaSuperficieBitmap(ddraw,"DECORADO",MODO_X,MODO_Y);
	sprites = CreaSuperficieBitmap(ddraw,"CARACTERES",92,15);

	DDCOLORKEY ddck;
    ddck.dwColorSpaceLowValue  = 0x7ff; //16-bit cian 0,FF,FF
    ddck.dwColorSpaceHighValue = ddck.dwColorSpaceLowValue;
    sprites->SetColorKey(DDCKEY_SRCBLT, &ddck);
	
	f[1]=1; f[2]=1; f[3]=1;

	while(1)
    {
		if(PeekMessage(&msg, NULL,0,0,PM_REMOVE))
		{
			if(msg.message==WM_QUIT) break;
			TranslateMessage (&msg);
			DispatchMessage (&msg);        
		}
		else 
		{ 
			//esto es el tradicional bucle principal
			LeeTeclado();
			Redibuja();
			Comprueba();
			xh=x;
		}
	}
//el primer par�metro es nulo pues hemos destru�do hwnd
ShowCursor(TRUE); MessageBox(NULL,"FIN DEL JUEGO","Mario Bros. XE",MB_ICONEXCLAMATION | MB_OK);
return msg.wParam;
}



// FUNCIONES ////////////////////////////////////////////////////////
LRESULT CALLBACK WndFunc(HWND hwnd, UINT mensaje, WPARAM wParam, LPARAM lParam)
{
     HDC         hdc;
     PAINTSTRUCT ps;

	switch (mensaje)
    {
		case WM_PAINT:
			hdc = BeginPaint (hwnd, &ps);
			EndPaint (hwnd, &ps);
			break;

		case WM_KEYDOWN:
			switch(wParam)
            {
				case VK_ESCAPE:
					PostMessage(hwnd, WM_CLOSE, 0, 0);
				break;
            }
            break;
		case WM_RBUTTONUP:
			bros^=1;
			break;
        case WM_DESTROY:
			Destruye();
			PostQuitMessage (0);
			break;
		default:
			return DefWindowProc (hwnd, mensaje, wParam, lParam);
}
return 0;
}

void Comprueba()
{
BOOL ol;

	ol=Solap(a,91,TROOPA);
	if (ol&&jt) f[1]=0; /*s�lo mata cuando baja*/
	if (ol&&f[1]) {f[1]=1; f[2]=1; f[3]=1;x=26; xh; y=177;}//{PostMessage(hwnd, WM_CLOSE, 0, 0);return;}
	ol=Solap(b,156,BOMBOMB);
	if (ol&&jt) f[2]=0;
	if (ol&&f[2]) {f[1]=1; f[2]=1; f[3]=1;x=26; xh; y=177;}//PostMessage(hwnd, WM_CLOSE, 0, 0);
	ol=Solap(c,181,GOOMBA);
	if (ol&&jt) f[3]=0;
	if (ol&&f[3]) {f[1]=1; f[2]=1; f[3]=1;x=26; xh; y=177;}//PostMessage(hwnd, WM_CLOSE, 0, 0);
	ol=Solap(d,48,BOWSER);
	if (ol) {f[1]=1; f[2]=1; f[3]=1;x=26; xh; y=177;}//PostMessage(hwnd, WM_CLOSE, 0, 0);
	ol=Solap(193,(INT)e,PARATROOPA);
	if (ol) {f[1]=1; f[2]=1; f[3]=1;x=26; xh; y=177;}//PostMessage(hwnd, WM_CLOSE, 0, 0);
}

void LeeTeclado()
{
short l, r, u;
	
//hace and con el bit m�s significativo de los 2 bytes que devuelve
//para saber si la tecla est� #ahora# abajo
l = GetAsyncKeyState(VK_LEFT) & 0x8000;
r = GetAsyncKeyState(VK_RIGHT) & 0x8000;
u = GetAsyncKeyState(VK_UP) & 0x8000;
//l = GetAsyncKeyState(VK_LEFT) != 0;
//r = GetAsyncKeyState(VK_RIGHT)? 1 : 0;

	if (l&&!r) {--x; wd[0]=DDBLTFX_MIRRORLEFTRIGHT; Anda();}
	if (r&&!l) {++x; wd[0]=0; Anda();}

	if (u&&!jt) Salta(); /*poniendo ||jc) salta a una cierta altura*/
    if (!u) {jc=0; jt=1;} /*poniendo esto medimos el salto*/

    x1=((wd[0]!=0)*7+x-12)/8; x2=((wd[0]!=0)*(-7)+x-5)/8;
        
    y2=(y+7)/8*37; ys=map[x1+y2]||map[x2+y2]; /*si se cae ysuelo=0*/
    if (!ys&&!jc) {++y; wd[0]=jd; jt=1;}
    if (ys&&!u) {jd=wd[0]; jt=0;} /*con &&!k8 hacemos saltos no repetitivos*/
}

void Redibuja()
{
	RECT rpinta;
	DDBLTFX ddfx;
	ddfx.dwSize=sizeof(ddfx);

//	if(sprites->IsLost()==DDERR_SURFACELOST) sprites->Restore();
//	if(fondo->IsLost()==DDERR_SURFACELOST) fondo->Restore();
//	if(pag_visibl->IsLost()==DDERR_SURFACELOST) pag_visibl->Restore();
	
	pag_dibujo->BltFast(0,0,fondo,NULL,DDBLTFAST_NOCOLORKEY| DDBLTFAST_WAIT);
	
	rpinta.left = x;
	rpinta.top = y;
	rpinta.right = x+dimrcancho[0];
	rpinta.bottom = y+dimrcalto[0];
	ddfx.dwDDFX=wd[0];
	pag_dibujo->Blt(&rpinta,sprites,&rcsprites[bros],DDBLT_KEYSRC|DDBLT_WAIT|DDBLT_DDFX,&ddfx);

	if (f[1]){
if (!wd[TROOPA]) {++a;if (a>170) wd[TROOPA]=DDBLTFX_MIRRORLEFTRIGHT;}
if (wd[TROOPA]) {--a;if (a<116) wd[TROOPA]=0;}
	rpinta.left = a;
	rpinta.top = 91;
	rpinta.right = a+dimrcancho[TROOPA];
	rpinta.bottom = 91+dimrcalto[TROOPA];
	ddfx.dwDDFX=wd[TROOPA];
	pag_dibujo->Blt(&rpinta,sprites,&rcsprites[TROOPA],DDBLT_KEYSRC|DDBLT_WAIT|DDBLT_DDFX,&ddfx);
	} else pag_dibujo->BltFast(a,91,sprites,&rcsprites[TROOPA+1],DDBLTFAST_SRCCOLORKEY|DDBLTFAST_WAIT);


	if(f[2]){
if (!wd[BOMBOMB]) {++b;if (b>100) wd[BOMBOMB]=DDBLTFX_MIRRORLEFTRIGHT;}
if (wd[BOMBOMB]) {--b;if (b<20) wd[BOMBOMB]=0;}
	rpinta.left = b;
	rpinta.top = 156;
	rpinta.right = b+dimrcancho[BOMBOMB];
	rpinta.bottom = 156+dimrcalto[BOMBOMB];
	ddfx.dwDDFX=wd[BOMBOMB];
	pag_dibujo->Blt(&rpinta,sprites,&rcsprites[BOMBOMB],DDBLT_KEYSRC|DDBLT_WAIT|DDBLT_DDFX,&ddfx);
	}

	if(f[3]){
if (!wd[GOOMBA]) {++c;if (c>283) wd[GOOMBA]=1;}
if (wd[GOOMBA]) {--c;if (c<20) wd[GOOMBA]=0;}
	pag_dibujo->BltFast(c,181,sprites,&rcsprites[GOOMBA],DDBLTFAST_SRCCOLORKEY|DDBLTFAST_WAIT);
	}

if (!wd[PARATROOPA]) {e+=.5;if (e>77) wd[PARATROOPA]=1;}
if (wd[PARATROOPA]) {e-=.5;if (e<48) wd[PARATROOPA]=0;}
	pag_dibujo->BltFast(193,(LONG)e,sprites,&rcsprites[PARATROOPA],DDBLTFAST_SRCCOLORKEY|DDBLTFAST_WAIT);

if (!wd[BOWSER]) {d+=2;if (d>114) wd[BOWSER]=DDBLTFX_MIRRORLEFTRIGHT;}
if (wd[BOWSER]) {d-=2;if (d<44) wd[BOWSER]=0;}
	rpinta.left = d;
	rpinta.top = 48;
	rpinta.right = d+dimrcancho[BOWSER];
	rpinta.bottom = 48+dimrcalto[BOWSER];
	ddfx.dwDDFX=wd[BOWSER];
	pag_dibujo->Blt(&rpinta,sprites,&rcsprites[BOWSER],DDBLT_KEYSRC|DDBLT_WAIT|DDBLT_DDFX,&ddfx);

	pag_visibl->Flip(0,DDFLIP_WAIT);
	}

void Anda()
{
int x3, y3;

x3=((wd[0]!=0)*(-9)+x-3)/8; y3=(y+6)/8*37;
if (map[x3+y3]==2) PostMessage(hwnd, WM_CLOSE, 0, 0);
if (map[x3+y3]==1) x=xh; /*si se choca de morros se para*/
}

void Salta()
{
int y1;

y1=(y-4)/8*37;
--y; wd[0]=jd;
++jc;
if ((jc==34)||map[x1+y1]||map[x2+y1]) {jt=1; jc=0;} /*si toca techo o se acaba*/
}

void DimensionaSprites()
{
HANDLE file;
DWORD lp;
char i;
long lng;

file=CreateFile("smb.spr",GENERIC_READ,0,NULL,OPEN_EXISTING,NULL,NULL);
for(i=0;i<NUM_SPR;i++){
ReadFile(file,&lng,4,&lp,NULL);
rcsprites[i].left=lng&0x000000ff;
rcsprites[i].top=(lng&0x0000ff00)>>8;
rcsprites[i].right=(dimrcancho[i]=(lng&0x00ff0000)>>16)+rcsprites[i].left;
rcsprites[i].bottom=(dimrcalto[i]=(lng&0xff000000)>>24)+rcsprites[i].top;
}
CloseHandle(file);
}

void CargaMapa()
{
HANDLE file;
DWORD lp;

file=CreateFile("smb.map",GENERIC_READ,0,NULL,OPEN_EXISTING,NULL,NULL);
ReadFile(file,&map,888,&lp,NULL);
CloseHandle(file);	
}

IDirectDrawSurface* CreaSuperficieBitmap(IDirectDraw* directdraw, LPCTSTR file, int dw, int dh)
{
	HBITMAP hbm;
	BITMAP bm;
	DDSURFACEDESC surfdesc;
	IDirectDrawSurface* superficie;
	HDC hdcbitmap; 
	HDC hdcsuperficie;

	hbm = (HBITMAP)LoadImage(GetModuleHandle(NULL),
		file, 
		IMAGE_BITMAP, 
		dw, 
		dh, 
		LR_CREATEDIBSECTION);

	GetObject(hbm,sizeof(bm),&bm);

	ZeroMemory(&surfdesc, sizeof(surfdesc));
	surfdesc.dwSize = sizeof(surfdesc);
	surfdesc.dwFlags = DDSD_CAPS|DDSD_HEIGHT|DDSD_WIDTH;
	surfdesc.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
	surfdesc.dwWidth = bm.bmWidth;
	surfdesc.dwHeight = bm.bmHeight;
	if( directdraw->CreateSurface(&surfdesc,&superficie,NULL) != DD_OK) return NULL;

	hdcbitmap = CreateCompatibleDC(NULL);
	SelectObject(hdcbitmap,hbm);
	superficie->GetDC(&hdcsuperficie);

	StretchBlt(	hdcsuperficie,
				0,
				0,  
				surfdesc.dwWidth,
				surfdesc.dwHeight,
				hdcbitmap,
				0,
				0,
				bm.bmWidth,
				bm.bmHeight,
				SRCCOPY);

	superficie->ReleaseDC(hdcsuperficie);
	DeleteDC(hdcbitmap);

	DeleteObject(hbm);

	return superficie;
}

BOOL IniciaVentana( HINSTANCE hInst, int nCmdMuestra )
{
     WNDCLASS    wndclass;
     char szAppName[] = "Mario";

     wndclass.style         = CS_DBLCLKS;
     wndclass.lpfnWndProc   = WndFunc;		 
     wndclass.cbClsExtra    = 0;			 
     wndclass.cbWndExtra    = 0;			
     wndclass.hInstance     = hInst; 
     wndclass.hIcon         = LoadIcon (hInst,MAKEINTRESOURCE("MARIO"));
     wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
     wndclass.hbrBackground = (HBRUSH) GetStockObject (BLACK_BRUSH);
     wndclass.lpszMenuName  = NULL;
     wndclass.lpszClassName = szAppName;

     RegisterClass (&wndclass);

     hwnd = CreateWindowEx (
                    WS_EX_TOPMOST,         
                    szAppName,             
                    "Mario Bros. XE",
                    WS_VISIBLE | WS_POPUP,//|WS_CAPTION, 
                    0,         
                    0,         
                    MODO_X,                   
                    MODO_Y,                 
                    NULL,                  
                    NULL,                  
                    hInst,        
                    NULL);              

     if (!hwnd)
		return FALSE;

     ShowWindow (hwnd, nCmdMuestra);
     UpdateWindow (hwnd);
     SetFocus(hwnd);
     ShowCursor(FALSE);
	
     return TRUE;
}

BOOL IniciaDirDraw()
{
	DirectDrawCreate(0,&ddraw,0);
	ddraw->SetCooperativeLevel( hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN/*|DDSCL_NOWINDOWCHANGES|DDSCL_ALLOWMODEX*/);
	ddraw->SetDisplayMode( MODO_X, MODO_Y, MODO_BPP);

	DDSURFACEDESC desc;
	desc.dwSize = sizeof(desc);
	desc.dwFlags = DDSD_BACKBUFFERCOUNT | DDSD_CAPS;
	desc.dwBackBufferCount = 1;
	desc.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;//|DDSCAPS_MODEX
	ddraw->CreateSurface(&desc,&pag_visibl,0);

	DDSCAPS ddscaps;
	ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
	pag_visibl->GetAttachedSurface(&ddscaps,&pag_dibujo);
	return TRUE;
}

void Destruye()
{
	pag_visibl->Release();
	ddraw->Release();
}

/*BOOL Solap(int s1x,int s1y,int s2x,int s2y,char s1,char s2)
{
if (s1x+dimrcancho[s1]<=s2x) return FALSE;
if (s2x+dimrcancho[s2]<=s1x) return FALSE;
if (s1y+dimrcalto[s1]<=s2y) return FALSE;
if (s2y+dimrcalto[s2]<=s1y) return FALSE;
return TRUE;*/
BOOL Solap(int sx,int sy,char sp)
{
if (x+dimrcancho[0]<=sx) return FALSE;
if (sx+dimrcancho[sp]<=x) return FALSE;
if (y+dimrcalto[0]<=sy) return FALSE;
if (sy+dimrcalto[sp]<=y) return FALSE;
return TRUE;
}
