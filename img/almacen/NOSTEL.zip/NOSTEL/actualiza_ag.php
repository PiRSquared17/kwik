<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta name="author" content="Daniel Cruz Horts" />
  <title>realizando acci&oacute;n</title>
</head>
<!--
cambia una entrada en la agenda de la operadora

VIENE DE: agendados
ENLAZA A: agendados
-->

<body>
<script type="text/javascript">
window.history.forward(1);
</script>

<?
$a=$_POST['nanyo'];
$m=$_POST['nmes'];
$d=$_POST['ndia'];
$fechaag=date('YmdHis',mktime(12,34,56,$m,$d,$a));

$link = mysql_connect('localhost','root');
mysql_select_db('nostel', $link);
mysql_query("UPDATE `".$_POST['listin']."` SET fecha=NOW(),fecha_ag='$fechaag',contacto='".$_POST['contacto']."',comentario='".$_POST['comentario']."' WHERE id='".$_POST['id']."'", $link);
?>

<form id="reag" action="agendados.php" method="post">
<div>
      <input type="hidden" name="operadora" value="<?=$_POST['operadora']?>" />
      <input type="hidden" name="listin" value="<?=$_POST['listin']?>" />
      <input type="hidden" name="dia" value="<?=$_POST['dia']?>" />
      <input type="hidden" name="mes" value="<?=$_POST['mes']?>" />
      <input type="hidden" name="anyo" value="<?=$_POST['anyo']?>" />

</div>
</form>

<script type="text/javascript">
document.forms[0].submit();
</script>

</body>    <!--sin las etiquetas BODY el form-autosubmit no funciona en Mozilla !! -->
</html>

