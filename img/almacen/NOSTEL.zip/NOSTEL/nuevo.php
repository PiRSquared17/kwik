<?/*
gui�n destinado a extraer tel�fonos de la campa�a seleccionada
la operadora marcar� dicho tel�fono y despu�s ingresar� en el sistema
el resultado de su llamada

VIENE DE: trabajo
ENLAZA A: marcar , trabajo
*/

include('header.php');
?>


<form method="post" action="marcar.php">
<div>

<?
$link = mysql_connect('localhost','root');
mysql_select_db('nostel', $link);
$consulta = mysql_query("SELECT * FROM `".$_POST['listin']."` WHERE estado='0' LIMIT 1", $link);

//coge un (1) telefono 'presentable' (no 'usado')

//le marca como AGENDADO y 'usado' por la operadora
if ($consulta==null) die('Error fatal');

?>
<input type="hidden" name="operadora" value="<?=$_POST['operadora']?>" />
<input type="hidden" name="listin" value="<?=$_POST['listin']?>" />
<?

if ($result = mysql_fetch_array($consulta)) {

mysql_query("UPDATE `".$_POST['listin']."` SET fecha=NOW(),estado='1',contacto='NO CONTESTA',operadora='".$_POST['operadora']."' WHERE id='".$result['id']."'", $link);

print "<strong>Cliente: ".ereg_replace('�',' ',$result['APELLIDO']).'</strong><br />';
print "<strong>Ciudad: ".ereg_replace('�',' ',$result['CIUDAD']).'</strong><br />';
print "<strong>Tel�fono:</strong><h1>".ereg_replace('�',' ',$result['TELEFONO'])."</h1>";
?>

<input type="hidden" name="id" value="<?=$result['id']?>" />

<input type="submit" onclick="form.action='marcar.php'" value="Anotar contacto como..." />
<select name="contacto">
<option value="POSITIVO">POSITIVO</option>
<option value="NEGATIVO">NEGATIVO</option>
<option value="AGENDADO" selected="selected">AGENDADO</option>
<option value="NO CONTESTA">NO CONTESTA</option>
</select>

<br /><br />S�lo en caso de agendarlo, a�adir el tel�fono con este comentario y fecha:<br />
<input type="text" name="comentario" />
<?
    print '<select name="dia">';
    $d=date('d');
    for ($i=1;$i<32;$i++) {
      print "<option value='$i'";
      if ($i==$d) print ' selected="selected"';
      print ">$i</option>";
    }
    print '</select>';


    $meses=array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio",
    "Agosto","Septiembre","Octubre","Noviembre","Diciembre");

    print '<select name="mes">';
    $m=date('m');
    for ($i=1;$i<13;$i++) {
      print "<option value='$i'";
      if ($i==$m) print ' selected="selected"';
      print '>'.$meses[$i-1].'</option>';
    }
    print '</select>';

    print '<select name="anyo">';
    $a=date('Y');
    for ($i=2005;$i<=$a;$i++) {
      print "<option value='$i'";
      if ($i==$a) print ' selected="selected"';
      print ">$i</option>";
    }
    print '</select>';

} else {
  ?>
<h1>No quedan m�s registros en la base de datos.</h1><h1>Por favor, avise a su supervisor.</h1>
<br /><br /><input type="submit" onclick="form.action='trabajo.php'" value="Men�" />
<?
}; //a 'trabajo' s�lo va si hay error, esto obliga a anotar un resultado a la llamada
?>


</div>
</form>


</div>

</body>
</html>

