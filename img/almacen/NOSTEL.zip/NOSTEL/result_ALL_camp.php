<?/*
coge los nombres de las campa�as y los almacena en un array
ese array es el que lee result_comun e itera para sumar los resultados de las operadoras

INCLUIDO EN result_lara
INCLUYE A: result_comun
*/


//cogemos los nombres de las campa�as
$consulta = mysql_query("SELECT nombre FROM `listines` WHERE 1 ORDER BY nombre", $link);
while ($result=mysql_fetch_array($consulta)) {
$campanyass[]=$result['nombre'];
}


include('result_comun.php');
?>

<p>
Se incluyen los positivos que marcaron las operadoras en las campa�as de hoy, los<br />
positivos extra para cada campa�a y los positivos que no corresponden a ninguna campa�a.
</p>
</tr>
</table>

