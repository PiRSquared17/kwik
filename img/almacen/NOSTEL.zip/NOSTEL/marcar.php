<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta name="author" content="Daniel Cruz Horts" />
  <title>realizando acci&oacute;n</title>
</head>
<!--
almacena el resultado de la llamada en la tabla de esa campa�a

VIENE DE: nuevo
ENLAZA A: trabajo
-->

<body>
<script type="text/javascript">
window.history.forward(1);
</script>


<?
$a=$_POST['anyo'];
$m=$_POST['mes'];
$d=$_POST['dia'];
$fechaag='';
if($_POST['contacto']=='AGENDADO') $fechaag=date('YmdHis',mktime(12,34,56,$m,$d,$a));


$link = mysql_connect('localhost','root');
mysql_select_db('nostel', $link);
mysql_query("UPDATE `".$_POST['listin']."` SET fecha=NOW(),fecha_ag='$fechaag',contacto='".$_POST['contacto']."',comentario='".$_POST['comentario']."' WHERE id='".$_POST['id']."'", $link);
?>

<form id="borra" action="trabajo.php" method="post">
<div>
      <input type="hidden" name="operadora" value="<?=$_POST['operadora']?>">
      <input type="hidden" name="listin" value="<?=$_POST['listin']?>">
</div>
</form>

<script type="text/javascript">
document.forms[0].submit();
</script>

</body>
</html>

