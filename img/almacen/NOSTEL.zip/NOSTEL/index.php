<?/*
gui�n de inicio para toda operadora
ofrece la posibilidad de elegir campa�a, y su nombre de usuario

VIENE DE:
ENLAZA A: trabajo
*/

include('header.php');
?>


<h1>Identificaci�n operadora</h1>

<?
$link = mysql_connect("localhost","root");
mysql_select_db("nostel", $link);
?>

Por favor, seleccione operadora y list�n de trabajo:
<form action="trabajo.php" method="post">
<div>

<select name="operadora">
<?
//seleccionamos de la tabla 'operadoras' los nombres disponibles
$consulta = mysql_query("SELECT nombre FROM `operadoras` WHERE 1 ORDER BY nombre", $link);
while ($result=mysql_fetch_array($consulta)) {
print '<option value="'.$result['nombre'].'">'.$result['nombre'].'</option>';
}
?>
</select>

<select name="listin">
<?
//seleccionamos las campa�as disponibles de la tabla 'listines'
$consulta = mysql_query("SELECT nombre FROM `listines` WHERE 1 ORDER BY nombre", $link);
while ($result=mysql_fetch_array($consulta)) {
print '<option value="'.$result['nombre'].'">'.$result['nombre'].'</option>';
}
?>
</select>

<input type="submit" value="Entrar" />

</div>
</form>

</div>

</body>
</html>
