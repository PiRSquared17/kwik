<?/*
presenta una lista con los positivos que marcaron las operadoras un dia
permite a�adir, borrar y modificar, tanto en una campa�a concreta o no

VIENE DE: indexlara
ENLAZA A: pos_borra , pos_otro , index
*/

include('header.php');
?>

<h1>Administrador de 'POSITIVOS'</h1>

<?
$link = mysql_connect('localhost','root');
mysql_select_db('nostel', $link);

//cogemos los nombres de las operadoras
$consulta = mysql_query("SELECT nombre FROM `operadoras` WHERE 1 ORDER BY nombre", $link);
while ($result=mysql_fetch_array($consulta)) {
$operadoras[]=$result['nombre'];
}
//y de las campa�as
$consulta = mysql_query("SELECT nombre FROM `listines` WHERE 1 ORDER BY nombre", $link);
while ($result=mysql_fetch_array($consulta)) {
$campanyass[]=$result['nombre'];
}


$a=$_POST['anyo'];
$m=$_POST['mes'];
$d=$_POST['dia'];

//if ($d='%') $dd='%'; else
$dd=date('YmdHis',mktime(12,34,56,$m,$d,$a));
?>

Positivos <em>extra</em> para el dia <?="$d / $m / $a"?><br />

<form id="pos" action="pos_borra.php" method="post">
<div>
<input type="hidden" name="dia" value="<?=$d?>" />
<input type="hidden" name="mes" value="<?=$m?>" />
<input type="hidden" name="anyo" value="<?=$a?>" />
<input type="hidden" name="id" value="x" />
<input type="hidden" name="operadora" value="x" />
<input type="hidden" name="listin" value="x" />
<input type="hidden" name="positivos" value="x" />
</div>
</form>

<form action="#" method="post">
<table border="1">
<tr>
<th>FECHA</th>
<th>OPERADORA</th>
<th>CAMPA�A</th>
<th>POSITIVOS</th>
<th></th>
</tr>

<?
$consulta = mysql_query("SELECT * FROM `positivos` WHERE fecha LIKE '$dd' ORDER BY fecha,positivos,operadora,listin", $link);
while ($result=mysql_fetch_array($consulta)) {
?>
<tr>
<td><?=substr($result['fecha'], 6, 2)." / ".substr($result['fecha'], 4, 2)." / ".substr($result['fecha'], 0, 4)?></td>
<td><?=$result['operadora']?></td>
<td><?=$result['listin']?></td>
<td><?=$result['positivos']?></td>
<td><input name="br<?=$result['id']?>" type="button" value="borrar" onclick="
            getElementById('pos').id.value=<?=$result['id']?>;
            getElementById('pos').action='pos_borra.php';
            getElementById('pos').submit();
            " /></td>
</tr>
<?
}

//presenta esto si dia!=todos
//if ($d!=
?>

<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

<tr>
<td>
<?="$d / $m / $a"?>
</td>
<td>
<select name="operadora">
<?
foreach ($operadoras as $o) {
print "<option value='$o'>$o</option>";
}
?>
</select>
</td>
<td>
<select name="listin">
<?
foreach ($campanyass as $k) {
print "<option value='$k'>$k</option>";
}
print '<option value="-otra-">Otra no listada</option>';
?>
</select>
</td>
<td><input type="text" name="positivos" size="2" maxlength="2" value="1" /></td>
<td><input type="button" value="a�adir" onclick="
            getElementById('pos').operadora.value=operadora.value;
            getElementById('pos').listin.value=listin.value;
            getElementById('pos').positivos.value=positivos.value;
            getElementById('pos').action='pos_otro.php';
            getElementById('pos').submit();
            " /></td>
</tr>
<?
//si es un dia concreto, puede a�adir,
//al a�adir comprueba que esa operadora no tenga ya, en tal caso modifica (update en vez de insert)
?>
</table>
</form>

<form action="#" method="post">
<div>
<input type="button" value="Men�" onclick="
            getElementById('pos').action='indexlara.php';
            getElementById('pos').submit();
            " />
</div>
</form>

</div>

</body>
</html>

