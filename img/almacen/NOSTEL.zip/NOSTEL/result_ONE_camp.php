<?/*
coge el nombre de la campa�a elegida y lo almacena en un array, de un s�lo elemento
ese array es el que lee result_comun e itera para sumar los resultados de las operadoras
como s�lo hay un elemento, s�lo sale una campa�a, la seleccionada
presenta adem�s la posibilidad de borrar los registros positivos de las operadoras, y
los telefonos sin usar en la campa�a

INCLUIDO EN result_lara
INCLUYE A: result_comun
*/


$campanyass[]=$campanya;

include('result_comun.php');
?>

</tr>
</table>

<br />
En <strong><?=$campanya?></strong> se llevan utilizados
<b><?
$consulta = mysql_query("SELECT COUNT(*) FROM `$campanya` WHERE estado='1'", $link);
$result=mysql_fetch_array($consulta);
print $result['COUNT(*)'];
?></b>
registros de un total de
<strong><?
$consulta = mysql_query("SELECT COUNT(*) FROM `$campanya` WHERE 1", $link);
$result=mysql_fetch_array($consulta);
print $result['COUNT(*)'];
?></strong>
disponibles.

<form action="borrapos.php" method="post">
<div>
<input type="checkbox" onclick="bp.disabled=!bp.disabled;" />
<input type="submit" name="bp" value="Borrar los positivos" disabled="disabled" />...que marcaron las operadoras durante esta campa�a este d�a. Los positivos extra permanecen.
<input type="hidden" name="dia" value="<?=$_POST["dia"]?>" />
<input type="hidden" name="mes" value="<?=$_POST["mes"]?>" />
<input type="hidden" name="anyo" value="<?=$_POST["anyo"]?>" />
<input type="hidden" name="listin" value="<?=$campanya?>" />
</div>
</form>

