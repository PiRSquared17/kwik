<?/*
redispone los tel�fonos que fueron marcados como 'no contesta'
muestra los registros ganados

VIENE DE: positivos
ENLAZA A: positivos
*/

include('header.php');




$campanya=$_POST['listin'];

$link = mysql_connect('localhost','root');
mysql_select_db('nostel', $link);

//cuenta registros ocupados
$consulta = mysql_query("SELECT COUNT(*) FROM `$campanya` WHERE estado='1'", $link);
$result=mysql_fetch_array($consulta);
$antes=$result['COUNT(*)'];

//libera registros NO CONTESTA
mysql_query("UPDATE `$campanya` SET contacto='',operadora='',estado='0',comentario='' WHERE contacto='NO CONTESTA'", $link);

//recuenta registros ocupados
$consulta = mysql_query("SELECT COUNT(*) FROM `$campanya` WHERE estado='1'", $link);
$result=mysql_fetch_array($consulta);
$despues=$result['COUNT(*)'];
?>

Se han reutilizado <strong><?=$antes-$despues?></strong> registros.
Quedan
<strong><?
$consulta = mysql_query("SELECT COUNT(*) FROM `$campanya` WHERE estado='0'", $link);
$result=mysql_fetch_array($consulta);
print $result['COUNT(*)'];
?></strong>
disponibles en <strong><?=$campanya?></strong>.

<form id="reint" action="indexlara.php" method="post">
<input type="submit" value="Men�">
</form>

</div>

</body>
</html>

