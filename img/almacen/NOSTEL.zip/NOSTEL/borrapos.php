<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta name="author" content="Daniel Cruz Horts" />
  <title>realizando acci&oacute;n</title>
</head>
<!--
borra los positivos que marcaron las operadoras en esa campa�a ese dia
de este modo, el control de positivos lo lleva un administrador

VIENE DE: result_lara (result_ONE_camp)
ENLAZA A: result_lara
-->

<body>
<script type="text/javascript">
window.history.forward(1);
</script>


<?
$a=$_POST['anyo'];
$m=$_POST['mes'];
$d=$_POST['dia'];
$di=date('YmdHis',mktime(0,0,0,$m,$d,$a));
$df=date('YmdHis',mktime(23,59,59,$m,$d,$a));
$campanya=$_POST['listin'];

$link = mysql_connect('localhost','root');
mysql_select_db('nostel', $link);
mysql_query("UPDATE `$campanya` SET contacto='NEGATIVO' WHERE contacto='POSITIVO' AND fecha>'$di' AND fecha<'$df'", $link);
?>

<form id="bpos" action="result_lara.php" method="post">
<div>
<input type="hidden" name="dia" value="<?=$d?>">
<input type="hidden" name="mes" value="<?=$m?>">
<input type="hidden" name="anyo" value="<?=$a?>">
<input type="hidden" name="listin" value="<?=$campanya?>">
</div>
</form>

<script type="text/javascript">
document.forms[0].submit();
</script>

</body>
</html>
