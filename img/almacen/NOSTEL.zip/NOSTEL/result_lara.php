<?/*
presenta una tabla con los resultados de las llamadas efectuadas un dia
en una campa�a o en todas

VIENE DE: indexlara
ENLAZA A: indexlara , borrapos
INCLUYE A: result_ONE_camp , result_ALL_camp
*/

include('header.php');
?>

<h1>Administrador de llamadas</h1>

<?
$link = mysql_connect("localhost","root");
mysql_select_db("nostel", $link);
$campanya=$_POST['listin'];
$a=$_POST["anyo"];
$m=$_POST["mes"];
$d=$_POST["dia"];

?>

Viendo llamadas del <?=$d?>/<?=$m?>/<?=$a?> para <?=$campanya?>.<br />
Resultados que marcaron las operadoras y los positivos extra.<br />
<table>
<tr>
<th></th>
<th>POSITIVOS</th>
<th>NEGATIVOS</th>
<th>AGENDADOS</th>
<th>NO CONTESTA</th>
<th>Total</th>
</tr>

<?
//cogemos los nombres de las operadoras
$consulta = mysql_query("SELECT nombre FROM `operadoras` WHERE 1 ORDER BY nombre", $link);
while ($result=mysql_fetch_array($consulta)) {
$operadoras[]=$result['nombre'];
}

switch ($campanya) {
  case 'TODAS':
    include('result_ALL_camp.php');
  break;
  default:
    include('result_ONE_camp.php');
}
?>

<form action="indexlara.php" method="post">
<div>
<input type="hidden" name="dia" value="<?=$_POST["dia"]?>" />
<input type="hidden" name="mes" value="<?=$_POST["mes"]?>" />
<input type="hidden" name="anyo" value="<?=$_POST["anyo"]?>" />
<input type="hidden" name="listin" value="<?=$campanya?>" />
<input type="submit" value="realizar otra consulta..." />
</div>
</form>

</div>

</body>
</html>

