<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta name="author" content="Daniel Cruz Horts" />
  <title>realizando acci&oacute;n</title>
</head>
<!--
a�ade o modifica una entrada en la tabla de positivos extra

VIENE DE: positivos
ENLAZA A: positivos
-->

<body>
<script type="text/javascript">
window.history.forward(1);
</script>


<?
$a=$_POST['anyo'];
$m=$_POST['mes'];
$d=$_POST['dia'];
$fechapos=date('YmdHis',mktime(12,34,56,$m,$d,$a));

$link = mysql_connect('localhost','root');
mysql_select_db('nostel', $link);
$consulta=mysql_query("SELECT COUNT(*) FROM `positivos` WHERE fecha LIKE '$fechapos' AND operadora='".$_POST['operadora']."' AND listin='".$_POST['listin']."'", $link);

//si ya hay alguno, hace UPDATE. si no, hace INSERT
$result=mysql_fetch_array($consulta);
if ($result['COUNT(*)']>=1) $sql="UPDATE `positivos` SET fecha='$fechapos',positivos='".$_POST['positivos']."' WHERE fecha LIKE '$fechapos' AND operadora='".$_POST['operadora']."' AND listin='".$_POST['listin']."'";
  else $sql="INSERT INTO positivos (operadora,fecha,listin,positivos) VALUES('".$_POST['operadora']."','$fechapos','".$_POST['listin']."','".$_POST['positivos']."')";

mysql_query($sql);

?>

<form id="add" action="positivos.php" method="post">
<div>
      <input type="hidden" name="dia" value="<?=$d?>" />
      <input type="hidden" name="mes" value="<?=$m?>" />
      <input type="hidden" name="anyo" value="<?=$a?>" />
</div>
</form>

<script type="text/javascript">
document.forms[0].submit();
</script>

</body>
</html>

