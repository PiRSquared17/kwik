<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta name="author" content="Daniel Cruz Horts" />

  <title>Marcador de tel&eacute;fonos para NOSteL</title>

  <link rel="icon" href="icono.ico" type="image/icon" />
  <link rel="shortcut icon" href="icono.ico" type="image/icon" />
	<style type="text/css" media="all">
		@import "hoja.css";
	</style>
</head>

<body>

<script type="text/javascript">
window.history.forward(1);
</script>

<div id="principal">


<img src="nostel.png" alt="logo" />

