<?/*
guion principal para la operadora
desde aqu� se administra su trabajo diario
fundamentalmente: ver la agenda o pedir un nuevo n�mero

VIENE DE: index
ENLAZA A: agendados , nuevo
*/

include('header.php');
?>

<h1>Llamadas operadora</h1>

<form method="post" action="agendados.php">
<div>

<?
$link = mysql_connect("localhost","root");
mysql_select_db("nostel", $link);

print $_POST['operadora']." con tel�fonos de <strong>".$_POST['listin'];
?>
</strong>.

<input type="hidden" name="operadora" value="<?=$_POST['operadora']?>" />
<input type="hidden" name="listin" value="<?=$_POST['listin']?>" />

<br /><br /><input type="submit" onclick="form.action='nuevo.php'" value="Nuevo tel�fono" />
<br /><br /><input type="submit" onclick="form.action='agendados.php'" value="Ver agendados" />
para el d�a
<?
    print "<select name='dia'><option value='%'>todos</option>";
    for ($i=1;$i<32;$i++) {
      print "<option value='$i'>".$i."</option>";
    }
    print "</select>";


    $meses=array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio",
    "Agosto","Septiembre","Octubre","Noviembre","Diciembre");

    print "<select name='mes'>";
    $m=date("m");
    for ($i=1;$i<13;$i++) {
      print "<option value='$i'";
      if ($i==$m) print " selected='selected'";
      print ">".$meses[$i-1]."</option>";
    }
    print "</select>";

    print "<select name='anyo'>";
    $a=date("Y");
    for ($i=2005;$i<=$a+1;$i++) {
      print "<option value='$i'";
      if ($i==$a) print " selected='selected'";
      print ">$i</option>";
    }
    print "</select>";
?>


</div>
</form>

<?
$d=date("d");
$fechaag=date("YmdHis",mktime(12,34,56,$m,$d,$a));

$consulta = mysql_query("SELECT COUNT(*) FROM `".$_POST['listin']."` WHERE operadora='".$_POST['operadora']."' AND
                            contacto='AGENDADO' AND estado='1' AND fecha_ag LIKE '$fechaag'", $link);
$result=mysql_fetch_array($consulta);
$hay_ag_=$result['COUNT(*)'];

if ($hay_ag_>0) print "Hay <b>$hay_ag_</b> tel�fonos agendados para hoy d�a $d/$m/$a."
?>

</div>

</body>
</html>
