-- MySQL dump 9.11
--
-- Host: localhost    Database: nostel
-- ------------------------------------------------------
-- Server version	4.0.21

--
-- Table structure for table `aqui`
--

CREATE TABLE aqui (
  APELLIDO varchar(50) NOT NULL default '',
  id int(11) NOT NULL auto_increment,
  CIUDAD varchar(20) NOT NULL default '',
  TELEFONO varchar(20) NOT NULL default '',
  estado tinyint(4) NOT NULL default '0',
  operadora varchar(30) NOT NULL default '',
  contacto varchar(15) NOT NULL default '',
  fecha timestamp(14) NOT NULL,
  comentario varchar(255) NOT NULL default '',
  fecha_ag timestamp(14) NOT NULL default '00000000000000',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `aqui`
--

INSERT INTO aqui VALUES ('ap',1,'ci','tel',1,'YO','AGENDADO',20051110122223,'kl',20051110123456);
INSERT INTO aqui VALUES ('ap2',2,'ci','tel2',0,'YO','AGENDADO',20051110122105,'dhei',20051107123456);

--
-- Table structure for table `listines`
--

CREATE TABLE listines (
  nombre char(30) NOT NULL default '',
  PRIMARY KEY  (nombre)
) TYPE=MyISAM;

--
-- Dumping data for table `listines`
--

INSERT INTO listines VALUES ('aqui');

--
-- Table structure for table `operadoras`
--

CREATE TABLE operadoras (
  nombre char(30) NOT NULL default '',
  PRIMARY KEY  (nombre)
) TYPE=MyISAM;

--
-- Dumping data for table `operadoras`
--

INSERT INTO operadoras VALUES ('YO');

--
-- Table structure for table `positivos`
--

CREATE TABLE positivos (
  id int(11) NOT NULL auto_increment,
  operadora char(30) NOT NULL default '',
  listin char(30) NOT NULL default '',
  positivos int(11) NOT NULL default '0',
  fecha timestamp(14) NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `positivos`
--


