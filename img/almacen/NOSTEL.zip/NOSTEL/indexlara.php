<?/*
gui�n de inicio para juani o lara
permite ver los resultados de las llamadas de las operadoras, a�adir contactos positivos
y reutilizar tel�fonos

VIENE DE:
ENLAZA A: result_lara , positivos , reintegrar
*/

include('header.php');
?>

<h1>Administrador de llamadas</h1>
Tareas posibles:

<form action="result_lara.php" method="post">
<div>
<ul>
<li>
<input type="submit" value="Ver..." />...las llamadas de las operadoras el
<?
    print '<select name="dia">';
    $d=date('d');
    for ($i=1;$i<32;$i++) {
      print "<option value='$i'";
      if ($i==$d) print ' selected="selected"';
      print ">$i</option>";
    }
    print '</select>';


    $meses=array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio",
    "Agosto","Septiembre","Octubre","Noviembre","Diciembre");

    print '<select name="mes">';
    $m=date('m');
    for ($i=1;$i<13;$i++) {
      print "<option value='$i'";
      if ($i==$m) print ' selected="selected"';
      print '>'.$meses[$i-1].'</option>';
    }
    print '</select>';

    print '<select name="anyo">';
    $a=date('Y');
    for ($i=2005;$i<=$a;$i++) {
      print "<option value='$i'";
      if ($i==$a) print ' selected="selected"';
      print ">$i</option>";
    }
    print '</select>';
?>

<?
$link = mysql_connect('localhost','root');
mysql_select_db('nostel', $link);
?>

<select name="listin">
<?
$consulta = mysql_query("SELECT nombre FROM `listines` WHERE 1 ORDER BY nombre", $link);
while ($result=mysql_fetch_array($consulta)) {
print '<option value="'.$result['nombre'].'"';
if ($_POST['listin']==$result['nombre']) print 'selected="selected"';
print '>'.$result['nombre'].'</option>';
}
?>
<option value="TODAS">TODAS LAS CAMPA�AS</option>

</select>
</li>

<li><input type="submit" onclick="form.action='positivos.php'" value="Administrar 'POSITIVOS'..." />...para el dia indicado</li>

<li><input type="submit" onclick="form.action='reintegrar.php'" value="Reofrecer..." />...tel�fonos marcados como 'NO CONTESTA'</li>
</ul>

</div>
</form>

</div>

</body>
</html>

