<?/*
coge las campa�as seleccionadas y busca los resultados de las operadoras ese dia
presenta una tabla

INCLUIDO EN result_ONE_camp , result_ALL_camp
*/


foreach ($operadoras as $o) {
$t_op=0;
print "<tr>";
print "<td>$o</td>";

$di=date("YmdHis",mktime(0,0,0,$m,$d,$a));
$df=date("YmdHis",mktime(23,59,59,$m,$d,$a));
$dpos=date("YmdHis",mktime(12,34,56,$m,$d,$a)); //la fecha de los positivos extra


$op_pos=0;
//mira los positivos en dos tablas: la extra y la de la campa�a

//suma primero los positivos extra de la campa�a -otra-, para s�lo hacerlo una vez
if ($campanya=='TODAS') {
  $consulta = mysql_query("SELECT positivos FROM `positivos` WHERE operadora='$o' AND listin='-otra-' AND fecha LIKE '$dpos'", $link);
  $result=mysql_fetch_array($consulta);
  $op_pos+=$result['positivos'];
}

foreach ($campanyass as $k) {
//suma los positivos extra de la campa�a en concreto
  $consulta = mysql_query("SELECT positivos FROM `positivos` WHERE operadora='$o' AND listin='$k' AND fecha LIKE '$dpos'", $link);
  $result=mysql_fetch_array($consulta);
  $op_pos+=$result['positivos'];

//suma ahora los que marcaron las operadoras
  $consulta = mysql_query("SELECT COUNT(*) FROM `$k` WHERE operadora='$o' AND estado='1' AND contacto='POSITIVO'
AND fecha>'$di' AND fecha<'$df'", $link);
  $result=mysql_fetch_array($consulta);
  $op_pos+=$result['COUNT(*)'];
}
print "<td>$op_pos</td>";

$op_neg=0;
foreach ($campanyass as $k) {
  $consulta = mysql_query("SELECT COUNT(*) FROM `$k` WHERE operadora='$o' AND estado='1' AND contacto='NEGATIVO'
AND fecha>'$di' AND fecha<'$df'", $link);
  $result=mysql_fetch_array($consulta);
  $op_neg+=$result['COUNT(*)'];
}
print "<td>$op_neg</td>";

$op_agen=0;
foreach ($campanyass as $k) {
  $consulta = mysql_query("SELECT COUNT(*) FROM `$k` WHERE operadora='$o' AND estado='1' AND contacto='AGENDADO'
AND fecha>'$di' AND fecha<'$df'", $link);
  $result=mysql_fetch_array($consulta);
  $op_agen+=$result['COUNT(*)'];
}
print "<td>$op_agen</td>";

$op_nc=0;
foreach ($campanyass as $k) {
  $consulta = mysql_query("SELECT COUNT(*) FROM `$k` WHERE operadora='$o' AND estado='1' AND contacto='NO CONTESTA'
AND fecha>'$di' AND fecha<'$df'", $link);
  $result=mysql_fetch_array($consulta);
  $op_nc+=$result['COUNT(*)'];
}
print "<td>$op_nc</td>";

//suma a totales
$t_op+=$op_pos+$op_neg+$op_agen+$op_nc;
print "<td>$t_op</td>";

$totales+=$t_op;

$t_pos+=$op_pos;
$t_neg+=$op_neg;
$t_agen+=$op_agen;
$t_nc+=$op_nc;

print "</tr>";
}

print "<tr><td>Todas las operadoras</td><td>$t_pos</td><td>$t_neg</td><td>$t_agen</td><td>$t_nc</td><td>$totales</td>";
//lee cada operadora, y hace una consulta de num. agendados, positivos etc,, lleva computo

?>

