<?/*
gui�n destinado a administrar la agenda de la operadora en la campa�a seleccionada
permite cambiar estado, fecha y comentario de cada registro
es posible listarlos para un dia, o la agenda completa

VIENE DE: trabajo
ENLAZA A: actualiza_ag , trabajo
*/

include('header.php');

$a=$_POST['anyo'];
$m=$_POST['mes'];
$d=$_POST['dia'];
($d=='%')?$fechaag='%':$fechaag=date('YmdHis',mktime(12,34,56,$m,$d,$a));

($d=='%')?print '<h1>Tel�fonos agendados:</h1>':print "<h1>Tel�fonos agendados para el $d/$m/$a :</h1>";

$link = mysql_connect('localhost','root');
mysql_select_db('nostel', $link);
$consulta = mysql_query("SELECT * FROM `".$_POST['listin']."` WHERE operadora='".$_POST['operadora']."' AND
                            contacto='AGENDADO' AND estado='1' AND fecha_ag LIKE '$fechaag' ORDER BY fecha_ag DESC", $link);

print 'Tel�fonos agendados de '.$_POST['operadora'].' en '.$_POST['listin'];

//separo el formulario de envio del de la tabla para reducir la sobrecarga de env�o
//name no es id
?>

<form id="f1" action="actualiza_ag.php" method="post">
<div>
      <input type="hidden" name="operadora" value="<?=$_POST['operadora']?>" />
      <input type="hidden" name="listin" value="<?=$_POST['listin']?>" />
      <input type="hidden" name="id" value="x" />
      <input type="hidden" name="ndia" />
      <input type="hidden" name="nmes" />
      <input type="hidden" name="nanyo" />
      <input type="hidden" name="dia" />
      <input type="hidden" name="mes" />
      <input type="hidden" name="anyo" />
      <input type="hidden" name="comentario" />
      <input type="hidden" name="contacto" />
</div>
</form>

<form action="#" method="post">
<table border="1">
  <tr style="background-color:#BBBBBB">
    <th>Nombre</th>
    <th>Tel�fono</th>
    <th>Comentario</th>
    <th>Fecha agenda</th>
    <th>Reanotar como...</th>
  </tr>

<?
$tot=0;

while ($result = mysql_fetch_array($consulta)) {

$c^=0xEEEEEE;
?>

  <tr style="background-color:#<?=dechex($c)?>">
    <td><?=ereg_replace('�',' ',$result['APELLIDO'])?></td>
    <td><?=ereg_replace('�',' ',$result['TELEFONO'])?></td>
    <td><input type="text" name="comentario<?=$result['id']?>" value="<?=$result['comentario']?>" /></td>
    <td>
      <input type="text" size="2" maxlength="2" name="ndia<?=$result['id']?>" value="<?=substr($result['fecha_ag'], 6, 2)?>" />
      <input type="text" size="2" maxlength="2" name="nmes<?=$result['id']?>" value="<?=substr($result['fecha_ag'], 4, 2)?>" />
      <input type="text" size="4" maxlength="4" name="nanyo<?=$result['id']?>" value="<?=substr($result['fecha_ag'], 0, 4)?>" />
    </td>
    <td>
      <input type="hidden" name="dia<?=$result['id']?>" value="<?=$d?>" />
      <input type="hidden" name="mes<?=$result['id']?>" value="<?=$m?>" />
      <input type="hidden" name="anyo<?=$result['id']?>" value="<?=$a?>" />
    <select name="contacto<?=$result['id']?>">
      <option value="POSITIVO">POSITIVO</option>
      <option value="NEGATIVO">NEGATIVO</option>
      <option value="AGENDADO" selected="selected">REAGENDAR</option>
      <option value="NO CONTESTA">NO CONTESTA</option>
      </select>
      <input type="button" name="ac<?=$result['id']?>" value="actualiza" onclick="
            getElementById('f1').comentario.value=comentario<?=$result['id']?>.value;
            getElementById('f1').ndia.value=ndia<?=$result['id']?>.value;
            getElementById('f1').nmes.value=nmes<?=$result['id']?>.value;
            getElementById('f1').nanyo.value=nanyo<?=$result['id']?>.value;
            getElementById('f1').id.value=<?=$result['id']?>;
            getElementById('f1').dia.value=dia<?=$result['id']?>.value;
            getElementById('f1').mes.value=mes<?=$result['id']?>.value;
            getElementById('f1').anyo.value=anyo<?=$result['id']?>.value;
            getElementById('f1').contacto.value=contacto<?=$result['id']?>.value;
            getElementById('f1').submit();
            " />
    </td>
  </tr>

<?
++$tot;

}
?>

</table>
</form>
<?print "$tot registros.";?>


<form method="post" action="#">
<div>
<input type="hidden" name="operadora" value="<?=$_POST['operadora']?>" />
<input type="hidden" name="listin" value="<?=$_POST['listin']?>" />

<input type="submit" onclick="action='trabajo.php'" value="Men�" />
<input type="submit" onclick="action='nuevo.php'" value="Nuevo tel�fono" />
</div>
</form>

<?
function fechabien($timestamp) {
  //convierte una fecha yyyymmddhhmmss a una cadena dd/mm/yy
        $year = substr($timestamp, 0, 4);
        $month = substr($timestamp, 4, 2);
        $day = substr($timestamp, 6, 2);
        return $date = date('d / M / Y', mktime(0, 0, 0, $month, $day, $year));
}
?>

</div>

</body>
</html>

